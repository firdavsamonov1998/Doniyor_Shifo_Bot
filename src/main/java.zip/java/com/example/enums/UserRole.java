package com.example.enums;

public enum UserRole {
    NURSE, ACCOUNTENT

}
