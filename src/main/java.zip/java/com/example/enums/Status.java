package com.example.enums;

public enum Status {
    BLOCK, ACTIVE
}
