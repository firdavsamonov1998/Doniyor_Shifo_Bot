package com.example.step;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@NoArgsConstructor
@Getter
@Setter


public class TelegramUsers {

    private Long chatId;

    private Step step;



}
